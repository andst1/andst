function processThis(obj,fn){
	return function(e){fn.call(obj,e);}
}
function on(ele,type,handler){
	if(typeof ele["on"+type]=="undefined"){
		//判断如果不是系统事件
		//如果是自定义事件，则aSelf做前缀
		if(!ele["aSelf"+type]){
			ele["aSelf"+type]=[];
		}
		var a=ele["aSelf"+type]
		for(var i=0;i<a.length;i++){
			if(a[i]==handler)return;
		}
		a.push(handler);
	}else{//处理系统事件
	if(ele.addEventListener){
		ele.addEventListener(type,handler,false);
		return;
	}
	if(!ele["aEvent"+type]){
		ele["aEvent"+type]=[];	
		ele.attachEvent("on"+type,processThis(ele,run));//确保变形后的run方法只被绑定一次
	}
	var a=ele["aEvent"+type];
	for(var i=0;i<a.length;i++){
		if(a[i]==handler)return;
	}
	a.push(handler);
	}
}
//fire是当约定的那件事发生的时候，负责通知。
function fire(selfType,systemEvent){
	//两个参数，selfType是自定义的事件类型
	//systemEvent是系统的事件对象
	var a=this["aSelf"+selfType];
	if(a){
		for(var i=0;i<a.length;i++){
			a[i].call(this,systemEvent);
		}
	}	
}
function run(){
	var e=window.event;
	var type=e.type;
	
	var a=this["aEvent"+type];
	
	if(a){
		e.target=e.srcElement;
		e.pageX=(document.documentElement.scrollLeft||document.body.scrollLeft)+e.clientX;
		e.pageY=(document.documentElement.scrollTop||document.body.scrollTop)+e.clientY;
		e.stopPropagation=function(){e.cancelBubble=true;}
		e.preventDefault=function(){
			e.returnValue=false;
		}
		for(var i=0;i<a.length;){
			if(typeof a[i]=="function"){//照应off里的69行a[i]=null这句脚本
				a[i].call(this,	e);
				i++;
			}else{
				a.splice(i,1);//把null项删除。但i不累加
			}
		}
	}
}
function off(ele,type,handler){
	if(ele.removeEventListener){
		ele.removeEventListener(type,handler,false);
		return;
	}
	var a=ele["aEvent"+type];
	if(a){
		for(var i=0;i<a.length;i++){
			if(a[i]==handler){
				a[i]=null;
				return;
			}
		}
	}
}