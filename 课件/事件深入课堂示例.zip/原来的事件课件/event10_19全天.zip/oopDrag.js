function EventEmiter(){
	
}
EventEmiter.prototype.on=function(type,handler){
	this;
	if(!this["eventEmiter"+type]){
		this["eventEmiter"+type]=[];
	}
	var a=this["eventEmiter"+type];
	for(var i=0;i<a.length;i++){
		if(a[i]==handler)return
	}
	a.push(handler);
}
EventEmiter.prototype.fire=function(type,ev,context){
	//第一个参数是必写：表示自定义的事件类型
	//第二个参数是必选：系统的事件对象
	//第三个参数是可选的：表示当a[i]运行的时候指定的上下文
	context=context||this;
	var a=this["eventEmiter"+type];
	if(a){
		for(var i=0;i<a.length;i++){
			a[i].call(context,ev);
		}
	}
}
EventEmiter.prototype.off=function(){
	var a=this["eventEmiter"+type];
	if(a){
		for(var i=0;i<a.length;i++){
			if(a[i]==handler){
				a[i]=null;
				return;	
			}
		}
	}
}

function Drag(ele){
	this.x=null;
	this.y=null;
	this.mx=null;
	this.my=null;
	this.ele=ele;
	this.range={}
	//原则：让类方法里的this无条件的指向Drag类的实例
	this.DOWN=processThis(this,this.down);
	this.MOVE=processThis(this,this.move);
	this.UP=processThis(this,this.up);
	on(ele,"mousedown",this.DOWN);	
}
Drag.prototype=new EventEmiter
Drag.prototype.down=function(e){
	this.x=this.ele.offsetLeft;
	this.y=this.ele.offsetTop;
	this.mx=e.pageX;
	this.my=e.pageY;
	if(this.ele.setCapture){
		on(this.ele,"mousemove",this.MOVE);
		on(this.ele,"mouseup",this.UP);
		this.ele.setCapture();
	}else{
		on(document,"mousemove",this.MOVE);
		on(document,"mouseup",this.UP);
	}
	e.preventDefault();
	this.fire("dragstart",e,this);
}
Drag.prototype.move=function(e){
	if(this.range){
		var l=this.range.left;
		var r=this.range.right;
		var t=this.range.top;
		var b=this.range.bottom;
		
		//下面是水平拖拽限定
		if(this.x+e.pageX-this.mx<=Number(l)){
			this.ele.style.left=l+"px";
		}else if(this.x+e.pageX-this.mx>=Number(r)){
			this.ele.style.left=r+"px";
		}else{
			this.ele.style.left=this.x+e.pageX-this.mx+"px";
		}
		//下面是垂直拖拽限定
		if(this.y+e.pageY-this.my<=Number(t)){
			this.ele.style.top=t+"px";
		}else if(this.y+e.pageY-this.my>=Number(b)){
			this.ele.style.top=b+"px";
		}else{
			this.ele.style.top=this.y+e.pageY-this.my+"px";
		}
		
	}
	this.fire("draging",e,this);//发布draging事件
}
Drag.prototype.up=function(e){
	if(this.ele.releaseCapture){
		off(this.ele,"mousemove",this.MOVE);
		off(this.ele,"mouseup",this.UP);
		this.ele.releaseCapture();
	}else{
		off(document,"mousemove",this.MOVE);
		off(document,"mouseup",this.UP);
	}
	this.fire("dragend",e,this);//发布dragend事件
}
Drag.prototype.limitDrag=function(oRange){
	this.range=oRange;
	this.fire("limitDrag",null,this);//发布limitDrag事件。
	//我们可以把任意一件事都发布成事件。其实就是给这个行为和其它行为留一个接口
	
}
Drag.prototype.border=function(){
	this.ele.style.border="1px dashed blue"
}
Drag.prototype.noneBorder=function(){
	this.ele.style.borderWidth="0px"
}
Drag.prototype.onDragBorder=function(){
	//使用事件，实现当拖拽开始的时候给被拖拽的元素加边框线。当拖拽结束的时候，去掉边线
	this.on("dragstart",this.border);
	this.on("dragend",this.noneBorder);
}